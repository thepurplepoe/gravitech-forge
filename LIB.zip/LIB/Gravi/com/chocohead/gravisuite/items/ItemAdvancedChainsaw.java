/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  com.google.common.base.CaseFormat
 *  com.google.common.collect.HashMultimap
 *  com.google.common.collect.Multimap
 *  ic2.api.item.ElectricItem
 *  ic2.api.item.IElectricItemManager
 *  ic2.core.IC2
 *  ic2.core.IC2Achievements
 *  ic2.core.init.Localization
 *  ic2.core.item.tool.ItemElectricTool
 *  ic2.core.item.tool.ItemElectricTool$HarvestLevel
 *  ic2.core.item.tool.ItemElectricTool$ToolClass
 *  ic2.core.ref.ItemName
 *  ic2.core.util.Keyboard
 *  ic2.core.util.StackUtil
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.ai.attributes.AttributeModifier
 *  net.minecraft.entity.ai.attributes.IAttribute
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.monster.EntityCreeper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.init.Enchantments
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.EnumRarity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.stats.StatBase
 *  net.minecraft.stats.StatList
 *  net.minecraft.util.ActionResult
 *  net.minecraft.util.EnumActionResult
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.text.TextFormatting
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.common.IShearable
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent
 *  net.minecraftforge.event.entity.player.PlayerInteractEvent$EntityInteract
 *  net.minecraftforge.fml.common.eventhandler.EventBus
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.registry.GameRegistry
 *  net.minecraftforge.fml.common.registry.IForgeRegistryEntry
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.chocohead.gravisuite.items;

import com.chocohead.gravisuite.Gravisuite;
import com.google.common.base.CaseFormat;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import ic2.api.item.ElectricItem;
import ic2.api.item.IElectricItemManager;
import ic2.core.IC2;
import ic2.core.IC2Achievements;
import ic2.core.init.Localization;
import ic2.core.item.tool.ItemElectricTool;
import ic2.core.ref.ItemName;
import ic2.core.util.Keyboard;
import ic2.core.util.StackUtil;
import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.IShearable;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.registry.IForgeRegistryEntry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ItemAdvancedChainsaw
extends ItemElectricTool {
    protected static final String NAME = "advancedChainsaw";

    public ItemAdvancedChainsaw() {
        super(null, 100, ItemElectricTool.HarvestLevel.Iron, EnumSet.of(ItemElectricTool.ToolClass.Axe, ItemElectricTool.ToolClass.Sword, ItemElectricTool.ToolClass.Shears));
        ((ItemAdvancedChainsaw)GameRegistry.register((IForgeRegistryEntry)this, (ResourceLocation)new ResourceLocation("gravisuite", "advancedChainsaw"))).setUnlocalizedName("advancedChainsaw");
        this.maxCharge = 45000;
        this.transferLimit = 500;
        this.tier = 2;
        this.efficiencyOnProperMaterial = 30.0f;
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    @SideOnly(value=Side.CLIENT)
    public void registerModels(ItemName name) {
        ModelLoader.setCustomModelResourceLocation((Item)this, (int)0, (ModelResourceLocation)new ModelResourceLocation("gravisuite:" + CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, "advancedChainsaw"), null));
    }

    public ActionResult<ItemStack> onItemRightClick(ItemStack stack, World world, EntityPlayer player, EnumHand hand) {
        if (!world.isRemote && IC2.keyboard.isModeSwitchKeyDown(player)) {
            NBTTagCompound nbt = StackUtil.getOrCreateNbtData((ItemStack)stack);
            if (nbt.getBoolean("disableShear")) {
                nbt.setBoolean("disableShear", false);
                Gravisuite.messagePlayer(player, "gravisuite.advancedChainsaw.shear", TextFormatting.DARK_GREEN, Localization.translate((String)"gravisuite.message.on"));
            } else {
                nbt.setBoolean("disableShear", true);
                Gravisuite.messagePlayer(player, "gravisuite.advancedChainsaw.shear", TextFormatting.DARK_RED, Localization.translate((String)"gravisuite.message.off"));
            }
            return new ActionResult(EnumActionResult.SUCCESS, (Object)stack);
        }
        return super.onItemRightClick(stack, world, player, hand);
    }

    public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
        ElectricItem.manager.use(stack, this.operationEnergyCost, attacker);
        if (attacker instanceof EntityPlayer && target instanceof EntityCreeper && target.getHealth() <= 0.0f) {
            IC2.achievements.issueAchievement((EntityPlayer)attacker, "killCreeperChainsaw");
        }
        return true;
    }

    @SubscribeEvent
    public void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        BlockPos pos;
        IShearable target;
        EntityPlayer player = event.getEntityPlayer();
        if (player.worldObj.isRemote) {
            return;
        }
        Entity entity = event.getTarget();
        ItemStack stack = player.inventory.getStackInSlot(player.inventory.currentItem);
        if (stack != null && stack.getItem() == this && entity instanceof IShearable && !StackUtil.getOrCreateNbtData((ItemStack)stack).getBoolean("disableShear") && ElectricItem.manager.use(stack, this.operationEnergyCost, (EntityLivingBase)player) && (target = (IShearable)entity).isShearable(stack, (IBlockAccess)entity.worldObj, pos = new BlockPos(entity))) {
            List drops = target.onSheared(stack, (IBlockAccess)entity.worldObj, pos, EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantments.FORTUNE, (ItemStack)stack));
            for (ItemStack drop : drops) {
                EntityItem item = entity.entityDropItem(drop, 1.0f);
                item.motionY += (double)(itemRand.nextFloat() * 0.05f);
                item.motionX += (double)((itemRand.nextFloat() - itemRand.nextFloat()) * 0.1f);
                item.motionZ += (double)((itemRand.nextFloat() - itemRand.nextFloat()) * 0.1f);
            }
        }
    }

    public boolean onBlockStartBreak(ItemStack stack, BlockPos pos, EntityPlayer player) {
        IShearable target;
        World world = player.worldObj;
        if (world.isRemote) {
            return false;
        }
        if (StackUtil.getOrCreateNbtData((ItemStack)stack).getBoolean("disableShear")) {
            return false;
        }
        Block block = world.getBlockState(pos).getBlock();
        if (block instanceof IShearable && (target = (IShearable)block).isShearable(stack, (IBlockAccess)world, pos) && ElectricItem.manager.use(stack, this.operationEnergyCost, (EntityLivingBase)player)) {
            List drops = target.onSheared(stack, (IBlockAccess)world, pos, EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantments.FORTUNE, (ItemStack)stack));
            for (ItemStack drop : drops) {
                StackUtil.dropAsEntity((World)world, (BlockPos)pos, (ItemStack)drop);
            }
            player.addStat(StatList.getBlockStats((Block)block), 1);
        }
        return false;
    }

    public String getUnlocalizedName() {
        return "gravisuite." + super.getUnlocalizedName().substring(4);
    }

    public EnumRarity getRarity(ItemStack stack) {
        return EnumRarity.UNCOMMON;
    }

    @SideOnly(value=Side.CLIENT)
    public void addInformation(ItemStack stack, EntityPlayer player, List<String> tooltip, boolean advanced) {
        super.addInformation(stack, player, tooltip, advanced);
        if (StackUtil.getOrCreateNbtData((ItemStack)stack).getBoolean("disableShear")) {
            tooltip.add((Object)TextFormatting.DARK_RED + Localization.translate((String)"gravisuite.advancedChainsaw.shear", (Object[])new Object[]{Localization.translate((String)"gravisuite.message.off")}));
        } else {
            tooltip.add((Object)TextFormatting.DARK_GREEN + Localization.translate((String)"gravisuite.advancedChainsaw.shear", (Object[])new Object[]{Localization.translate((String)"gravisuite.message.on")}));
        }
    }

    public Multimap<String, AttributeModifier> getAttributeModifiers(EntityEquipmentSlot slot, ItemStack stack) {
        if (slot != EntityEquipmentSlot.MAINHAND) {
            return super.getAttributeModifiers(slot, stack);
        }
        HashMultimap ret = HashMultimap.create();
        if (ElectricItem.manager.canUse(stack, this.operationEnergyCost)) {
            ret.put((Object)SharedMonsterAttributes.ATTACK_SPEED.getAttributeUnlocalizedName(), (Object)new AttributeModifier(ATTACK_SPEED_MODIFIER, "Tool modifier", (double)this.attackSpeed, 0));
            ret.put((Object)SharedMonsterAttributes.ATTACK_DAMAGE.getAttributeUnlocalizedName(), (Object)new AttributeModifier(Item.ATTACK_DAMAGE_MODIFIER, "Tool modifier", 13.0, 0));
        }
        return ret;
    }

    protected String getIdleSound(EntityLivingBase player, ItemStack stack) {
        return "Tools/Chainsaw/ChainsawIdle.ogg";
    }

    protected String getStopSound(EntityLivingBase player, ItemStack stack) {
        return "Tools/Chainsaw/ChainsawStop.ogg";
    }
}

