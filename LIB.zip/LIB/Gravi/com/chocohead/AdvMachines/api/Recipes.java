/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Iterables
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.api.recipe.IMachineRecipeManager$RecipeIoContainer
 *  ic2.api.recipe.IRecipeInput
 *  ic2.api.recipe.RecipeOutput
 *  ic2.api.recipe.Recipes
 *  ic2.core.recipe.BasicMachineRecipeManager
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 */
package com.chocohead.AdvMachines.api;

import com.chocohead.AdvMachines.api.IDualMachineRecipeManager;
import com.google.common.collect.Iterables;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.api.recipe.IRecipeInput;
import ic2.api.recipe.RecipeOutput;
import ic2.core.recipe.BasicMachineRecipeManager;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public enum Recipes implements IDualMachineRecipeManager
{
    rotaryMacerator(ic2.api.recipe.Recipes.macerator),
    singularityCompressor(ic2.api.recipe.Recipes.compressor),
    centrifugeExtractor(ic2.api.recipe.Recipes.extractor),
    compactingRecycler(ic2.api.recipe.Recipes.recycler),
    liquescentExtruder(ic2.api.recipe.Recipes.metalformerExtruding),
    impellerizedRoller(ic2.api.recipe.Recipes.metalformerRolling),
    waterJetCutter(ic2.api.recipe.Recipes.metalformerCutting),
    thermalWasher(ic2.api.recipe.Recipes.oreWashing);
    
    public static final ItemStack[] SKIP;
    private final IMachineRecipeManager base;
    private final IMachineRecipeManager extra;

    private Recipes(IMachineRecipeManager base) {
        this(base, (IMachineRecipeManager)new BasicMachineRecipeManager());
    }

    private Recipes(IMachineRecipeManager base, IMachineRecipeManager extra) {
        this.base = base;
        this.extra = extra;
    }

    public /* varargs */ boolean addRecipe(IRecipeInput input, NBTTagCompound metadata, boolean replace, ItemStack ... outputs) {
        return this.extra.addRecipe(input, metadata, replace, outputs);
    }

    public RecipeOutput getOutputFor(ItemStack input, boolean adjustInput) {
        RecipeOutput out = this.extra.getOutputFor(input, adjustInput);
        if (out == null) {
            out = this.base.getOutputFor(input, adjustInput);
        } else if (out.items.isEmpty()) {
            return null;
        }
        return out;
    }

    public boolean isIterable() {
        return true;
    }

    public Iterable<IMachineRecipeManager.RecipeIoContainer> getRecipes() {
        return this.base.isIterable() ? Iterables.concat((Iterable)this.base.getRecipes(), this.getExtraRecipes()) : this.getExtraRecipes();
    }

    @Override
    public Iterable<IMachineRecipeManager.RecipeIoContainer> getExtraRecipes() {
        return this.extra.getRecipes();
    }

    @Override
    public IMachineRecipeManager getDefault() {
        return this.base;
    }

    static {
        SKIP = new ItemStack[0];
    }
}

