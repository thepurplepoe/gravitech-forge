/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.api.recipe.IMachineRecipeManager$RecipeIoContainer
 */
package com.chocohead.AdvMachines.api;

import ic2.api.recipe.IMachineRecipeManager;

public interface IDualMachineRecipeManager
extends IMachineRecipeManager {
    public IMachineRecipeManager getDefault();

    public Iterable<IMachineRecipeManager.RecipeIoContainer> getExtraRecipes();
}

