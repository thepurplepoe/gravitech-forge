/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.core.block.ITeBlock
 *  net.minecraft.nbt.NBTTagCompound
 *  org.apache.commons.lang3.ArrayUtils
 */
package com.chocohead.AdvMachines.api;

import com.google.common.collect.ImmutableSet;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.core.block.ITeBlock;
import java.util.Collections;
import java.util.Set;
import net.minecraft.nbt.NBTTagCompound;
import org.apache.commons.lang3.ArrayUtils;

public interface IRecipeLoadingTeBlock
extends ITeBlock {
    public String[] getRecipeCategories();

    public IMachineRecipeManager getManager(String var1);

    public MachineType getType(String var1);

    public static final class MachineType
    extends Enum<MachineType> {
        public static final /* enum */ MachineType NORMAL = new MachineType();
        public static final /* enum */ MachineType RECYCLER = new MachineType("chance");
        public static final /* enum */ MachineType THERMAL_CENTRIFUGE = new MachineType("minHeat");
        private final Set<String> requiredTags;
        private static final /* synthetic */ MachineType[] $VALUES;

        public static MachineType[] values() {
            return (MachineType[])$VALUES.clone();
        }

        public static MachineType valueOf(String name) {
            return Enum.valueOf(MachineType.class, name);
        }

        private MachineType() {
            this.requiredTags = Collections.emptySet();
        }

        private /* varargs */ MachineType(String ... neededTags) {
            assert (!ArrayUtils.contains((Object[])neededTags, (Object)null));
            assert (neededTags.length > 0);
            this.requiredTags = ImmutableSet.copyOf((Object[])neededTags);
        }

        public boolean needsTags() {
            return !this.requiredTags.isEmpty();
        }

        public boolean hasRequiredTags(NBTTagCompound metadata) {
            for (String key : this.requiredTags) {
                if (metadata.func_74764_b(key)) continue;
                return false;
            }
            return true;
        }

        static {
            $VALUES = new MachineType[]{NORMAL, RECYCLER, THERMAL_CENTRIFUGE};
        }
    }

}

