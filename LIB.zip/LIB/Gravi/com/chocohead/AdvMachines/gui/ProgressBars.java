/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.core.gui.Gauge
 *  ic2.core.gui.Gauge$GaugeProperties
 *  ic2.core.gui.Gauge$GaugePropertyBuilder
 *  ic2.core.gui.Gauge$GaugePropertyBuilder$GaugeOrientation
 *  ic2.core.gui.Gauge$GaugeStyle
 *  ic2.core.gui.Gauge$IGaugeStyle
 *  net.minecraft.util.ResourceLocation
 */
package com.chocohead.AdvMachines.gui;

import ic2.core.gui.Gauge;
import java.util.Locale;
import net.minecraft.util.ResourceLocation;

public enum ProgressBars implements Gauge.IGaugeStyle
{
    PROGRESS_EXTRUDER(new Gauge.GaugePropertyBuilder(176, 14, 29, 19, Gauge.GaugePropertyBuilder.GaugeOrientation.Right).withBackground(1, 1, 28, 19, 78, 34).withTexture(new ResourceLocation("advanced_machines", "textures/gui/GUIExtruder.png")));
    
    private final String name;
    private final Gauge.GaugeProperties properties;

    private ProgressBars(Gauge.GaugePropertyBuilder properties) {
        this.name = this.name().toLowerCase(Locale.ENGLISH);
        this.properties = properties.build();
    }

    public Gauge.GaugeProperties getProperties() {
        return this.properties;
    }

    public static void addStyles() {
        for (ProgressBars bar : ProgressBars.values()) {
            Gauge.GaugeStyle.addStyle((String)bar.name, (Gauge.IGaugeStyle)bar);
        }
    }
}

