/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.chocohead.AdvMachines.te;

import com.chocohead.AdvMachines.api.Recipes;
import com.chocohead.AdvMachines.te.TileEntityHeatingMachine;
import ic2.api.recipe.IMachineRecipeManager;
import java.util.Random;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TileEntityRotaryMacerator
extends TileEntityHeatingMachine {
    private static final byte OUTPUTS = 2;

    public TileEntityRotaryMacerator() {
        super((byte)2, Recipes.rotaryMacerator);
    }

    @SideOnly(value=Side.CLIENT)
    protected void updateEntityClient() {
        super.updateEntityClient();
        if (this.getActive() && this.field_145850_b.field_73012_v.nextInt(8) == 0) {
            for (int i = 0; i < 4; ++i) {
                this.field_145850_b.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, (double)this.field_174879_c.func_177958_n() + 0.5 + (double)this.field_145850_b.field_73012_v.nextFloat() * 0.6 - 0.3, (double)(this.field_174879_c.func_177956_o() + 1) + (double)this.field_145850_b.field_73012_v.nextFloat() * 0.2 - 0.1, (double)this.field_174879_c.func_177952_p() + 0.5 + (double)this.field_145850_b.field_73012_v.nextFloat() * 0.6 - 0.3, 0.0, 0.0, 0.0, new int[0]);
            }
        }
    }

    @Override
    public String getSound() {
        return "Machines/MaceratorOp.ogg";
    }
}

