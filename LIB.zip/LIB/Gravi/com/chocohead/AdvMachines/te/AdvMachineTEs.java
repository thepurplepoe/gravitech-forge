/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.core.block.BlockTileEntity
 *  ic2.core.block.ITeBlock
 *  ic2.core.block.TileEntityBlock
 *  ic2.core.item.block.ItemBlockTileEntity
 *  ic2.core.ref.TeBlock
 *  ic2.core.ref.TeBlock$DefaultDrop
 *  ic2.core.ref.TeBlock$HarvestTool
 *  ic2.core.ref.TeBlock$ITePlaceHandler
 *  ic2.core.util.Util
 *  net.minecraft.block.material.Material
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.EnumRarity
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.common.Loader
 *  net.minecraftforge.fml.common.ModContainer
 */
package com.chocohead.AdvMachines.te;

import com.chocohead.AdvMachines.api.IRecipeLoadingTeBlock;
import com.chocohead.AdvMachines.api.Recipes;
import com.chocohead.AdvMachines.te.TileEntityCentrifugeExtractor;
import com.chocohead.AdvMachines.te.TileEntityCompactingRecycler;
import com.chocohead.AdvMachines.te.TileEntityImpellerizedRoller;
import com.chocohead.AdvMachines.te.TileEntityLiquescentExtruder;
import com.chocohead.AdvMachines.te.TileEntityRotaryMacerator;
import com.chocohead.AdvMachines.te.TileEntitySingularityCompressor;
import com.chocohead.AdvMachines.te.TileEntityThermalWasher;
import com.chocohead.AdvMachines.te.TileEntityWaterJetCutter;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.core.block.BlockTileEntity;
import ic2.core.block.ITeBlock;
import ic2.core.block.TileEntityBlock;
import ic2.core.item.block.ItemBlockTileEntity;
import ic2.core.ref.TeBlock;
import ic2.core.util.Util;
import java.util.List;
import java.util.Set;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;

public enum AdvMachineTEs implements IRecipeLoadingTeBlock
{
    rotary_macerator(TileEntityRotaryMacerator.class, 0),
    singularity_compressor(TileEntitySingularityCompressor.class, 1),
    centrifuge_extractor(TileEntityCentrifugeExtractor.class, 2),
    compacting_recycler(TileEntityCompactingRecycler.class, 3),
    liquescent_extruder(TileEntityLiquescentExtruder.class, 4),
    impellerized_roller(TileEntityImpellerizedRoller.class, 5),
    water_jet_cutter(TileEntityWaterJetCutter.class, 6),
    thermal_washer(TileEntityThermalWasher.class, 7);
    
    private final Class<? extends TileEntityBlock> teClass;
    private final int itemMeta;
    private TileEntityBlock dummyTe;
    private static final AdvMachineTEs[] VALUES;
    public static final ResourceLocation IDENTITY;

    private AdvMachineTEs(Class<? extends TileEntityBlock> teClass, int itemMeta) {
        this.teClass = teClass;
        this.itemMeta = itemMeta;
        TileEntity.func_145826_a(teClass, (String)("advanced_machines:" + this.getName()));
    }

    public boolean hasItem() {
        return true;
    }

    public String getName() {
        return this.name();
    }

    public int getId() {
        return this.itemMeta;
    }

    public ResourceLocation getIdentifier() {
        return IDENTITY;
    }

    public Class<? extends TileEntityBlock> getTeClass() {
        return this.teClass;
    }

    public boolean hasActive() {
        return true;
    }

    public float getHardness() {
        return 5.0f;
    }

    public float getExplosionResistance() {
        return 10.0f;
    }

    public TeBlock.HarvestTool getHarvestTool() {
        return TeBlock.HarvestTool.Pickaxe;
    }

    public TeBlock.DefaultDrop getDefaultDrop() {
        return TeBlock.DefaultDrop.AdvMachine;
    }

    public boolean allowWrenchRotating() {
        return false;
    }

    public Set<EnumFacing> getSupportedFacings() {
        return Util.horizontalFacings;
    }

    public EnumRarity getRarity() {
        return EnumRarity.UNCOMMON;
    }

    public Material getMaterial() {
        return Material.field_151573_f;
    }

    public void addSubBlocks(List<ItemStack> list, BlockTileEntity block, ItemBlockTileEntity item, CreativeTabs tab) {
        for (AdvMachineTEs type : VALUES) {
            if (!type.hasItem()) continue;
            list.add(block.getItemStack((ITeBlock)type));
        }
    }

    @Override
    public String[] getRecipeCategories() {
        return new String[]{this.getName()};
    }

    @Override
    public IMachineRecipeManager getManager(String category) {
        switch (this) {
            case rotary_macerator: {
                return Recipes.rotaryMacerator;
            }
            case singularity_compressor: {
                return Recipes.singularityCompressor;
            }
            case centrifuge_extractor: {
                return Recipes.centrifugeExtractor;
            }
            case compacting_recycler: {
                return Recipes.compactingRecycler;
            }
            case liquescent_extruder: {
                return Recipes.liquescentExtruder;
            }
            case impellerized_roller: {
                return Recipes.impellerizedRoller;
            }
            case water_jet_cutter: {
                return Recipes.waterJetCutter;
            }
            case thermal_washer: {
                return Recipes.thermalWasher;
            }
        }
        throw new IllegalStateException("Gee, we've no idea for " + this);
    }

    @Override
    public IRecipeLoadingTeBlock.MachineType getType(String category) {
        switch (this) {
            case compacting_recycler: {
                return IRecipeLoadingTeBlock.MachineType.RECYCLER;
            }
        }
        return IRecipeLoadingTeBlock.MachineType.NORMAL;
    }

    public void setPlaceHandler(TeBlock.ITePlaceHandler handler) {
        throw new UnsupportedOperationException("Advanced Machine's machines don't need place handlers!");
    }

    public TeBlock.ITePlaceHandler getPlaceHandler() {
        return null;
    }

    public boolean isTransparent() {
        return false;
    }

    public static void buildDummies() {
        ModContainer mc = Loader.instance().activeModContainer();
        if (mc == null || !"advanced_machines".equals(mc.getModId())) {
            throw new IllegalAccessError("Don't mess with this please.");
        }
        for (AdvMachineTEs block : VALUES) {
            if (block.teClass == null) continue;
            try {
                block.dummyTe = block.teClass.newInstance();
            }
            catch (Exception e) {
                if (!Util.inDev()) continue;
                e.printStackTrace();
            }
        }
    }

    public TileEntityBlock getDummyTe() {
        return this.dummyTe;
    }

    static {
        VALUES = AdvMachineTEs.values();
        IDENTITY = new ResourceLocation("advanced_machines", "machines");
    }

}

