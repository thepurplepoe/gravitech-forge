/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 */
package com.chocohead.AdvMachines.te;

import com.chocohead.AdvMachines.api.Recipes;
import com.chocohead.AdvMachines.te.TileEntityHeatingMachine;
import ic2.api.recipe.IMachineRecipeManager;

public class TileEntityImpellerizedRoller
extends TileEntityHeatingMachine {
    private static final byte OUTPUTS = 1;

    public TileEntityImpellerizedRoller() {
        super((byte)1, Recipes.impellerizedRoller, 1, 24);
    }
}

