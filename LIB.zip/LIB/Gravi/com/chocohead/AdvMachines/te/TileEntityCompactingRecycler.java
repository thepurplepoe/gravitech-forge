/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.item.IC2Items
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.api.recipe.RecipeOutput
 *  ic2.core.IC2
 *  ic2.core.block.invslot.InvSlotOutput
 *  ic2.core.block.invslot.InvSlotProcessable
 *  ic2.core.block.machine.tileentity.TileEntityRecycler
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 */
package com.chocohead.AdvMachines.te;

import com.chocohead.AdvMachines.api.Recipes;
import com.chocohead.AdvMachines.te.TileEntityHeatingMachine;
import ic2.api.item.IC2Items;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.api.recipe.RecipeOutput;
import ic2.core.IC2;
import ic2.core.block.invslot.InvSlotOutput;
import ic2.core.block.invslot.InvSlotProcessable;
import ic2.core.block.machine.tileentity.TileEntityRecycler;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class TileEntityCompactingRecycler
extends TileEntityHeatingMachine {
    private static final byte OUTPUTS = 1;
    protected static final ItemStack SCRAP = IC2Items.getItem((String)"crafting", (String)"scrap");
    protected static final ItemStack SCRAP_BOX = IC2Items.getItem((String)"crafting", (String)"scrap_box");

    public TileEntityCompactingRecycler() {
        super((byte)1, Recipes.compactingRecycler);
    }

    @Override
    protected int getSpeedFactor() {
        return 12;
    }

    @Override
    public void operate() {
        if (!this.canOperate()) {
            return;
        }
        RecipeOutput recipe = this.inputSlot.process();
        int chance = recipe.metadata == null ? TileEntityRecycler.recycleChance() : recipe.metadata.func_74762_e("chance");
        List output = recipe.items;
        if (chance > 1) {
            Iterator it = output.iterator();
            while (it.hasNext()) {
                it.next();
                if (IC2.random.nextInt(chance) == 0) continue;
                it.remove();
            }
        }
        this.processUpgrades(output);
        this.outputSlot.add(output);
        this.inputSlot.consume();
    }

    @Override
    public int getHeat() {
        return this.heat * 9;
    }

    @Override
    public String getSound() {
        return "Machines/RecyclerOp.ogg";
    }
}

