/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.core.ExplosionIC2
 *  ic2.core.ExplosionIC2$Type
 *  ic2.core.IC2
 *  ic2.core.util.Log
 *  ic2.core.util.LogCategory
 *  ic2.core.util.Util
 *  net.minecraft.entity.Entity
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.fluids.FluidTank
 *  org.apache.logging.log4j.Level
 */
package com.chocohead.AdvMachines.te;

import com.chocohead.AdvMachines.api.Recipes;
import com.chocohead.AdvMachines.te.TileEntityHeatingWaterMachine;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.core.ExplosionIC2;
import ic2.core.IC2;
import ic2.core.util.Log;
import ic2.core.util.LogCategory;
import ic2.core.util.Util;
import net.minecraft.entity.Entity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fluids.FluidTank;
import org.apache.logging.log4j.Level;

public class TileEntityThermalWasher
extends TileEntityHeatingWaterMachine {
    private static final byte OUTPUTS = 3;
    private static final short IDLE_WATER_USE = 5;
    private static final short ACTIVE_WATER_USE = 500;

    public TileEntityThermalWasher() {
        super((byte)3, Recipes.thermalWasher, 6, 48, (short)500);
    }

    @Override
    public int getHeat() {
        return this.heat * 100 / 10000;
    }

    @Override
    protected int getIdleWaterUse() {
        return (int)((double)this.heat / 10000.0 * 5.0);
    }

    @Override
    protected void onFluidFill(boolean didFill, int amount) {
        super.onFluidFill(didFill, amount);
        if (didFill && this.tank.getFluidAmount() - amount <= 0 && this.heat >= 5000) {
            IC2.log.log(LogCategory.PlayerActivity, Level.INFO, "Thermal Washer at %s exploded (%d water inserted at %d%% heat)", new Object[]{Util.formatPosition((TileEntity)this), amount, this.heat * 100 / 10000});
            ExplosionIC2 explosion = new ExplosionIC2(this.field_145850_b, null, this.field_174879_c, 12.0f, 0.0f, ExplosionIC2.Type.Heat);
            explosion.destroy(this.field_174879_c.func_177958_n(), this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p(), true);
            explosion.doExplosion();
        }
    }
}

