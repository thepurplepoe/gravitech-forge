/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 */
package com.chocohead.AdvMachines.te;

import com.chocohead.AdvMachines.api.Recipes;
import com.chocohead.AdvMachines.te.TileEntityHeatingMachine;
import ic2.api.recipe.IMachineRecipeManager;

public class TileEntityCentrifugeExtractor
extends TileEntityHeatingMachine {
    private static final byte OUTPUTS = 3;

    public TileEntityCentrifugeExtractor() {
        super((byte)3, Recipes.centrifugeExtractor);
    }
}

