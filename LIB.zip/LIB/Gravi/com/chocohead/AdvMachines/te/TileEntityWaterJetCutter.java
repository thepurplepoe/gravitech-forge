/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.core.gui.dynamic.IFluidTankProvider
 *  net.minecraft.world.World
 */
package com.chocohead.AdvMachines.te;

import com.chocohead.AdvMachines.api.Recipes;
import com.chocohead.AdvMachines.te.TileEntityHeatingWaterMachine;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.core.gui.dynamic.IFluidTankProvider;
import java.util.Random;
import net.minecraft.world.World;

public class TileEntityWaterJetCutter
extends TileEntityHeatingWaterMachine
implements IFluidTankProvider {
    private static final byte OUTPUTS = 1;
    protected static final short IDLE_WATER_USE = 2;
    protected static final short ACTIVE_WATER_USE = 500;

    public TileEntityWaterJetCutter() {
        super((byte)1, Recipes.waterJetCutter, 1, 24, (short)500);
    }

    @Override
    protected int getIdleWaterUse() {
        return (int)((double)this.heat / 10000.0 * 2.0 + this.field_145850_b.field_73012_v.nextDouble());
    }
}

