/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  ic2.api.recipe.IMachineRecipeManager
 *  ic2.api.recipe.IMachineRecipeManager$RecipeIoContainer
 *  ic2.api.recipe.IRecipeInput
 *  ic2.api.recipe.RecipeOutput
 *  ic2.core.block.BlockTileEntity
 *  ic2.core.block.ITeBlock
 *  ic2.core.ref.TeBlock
 *  ic2.core.util.ReflectionUtil
 *  ic2.jeiIntegration.recipe.machine.DynamicCategory
 *  ic2.jeiIntegration.recipe.machine.IORecipeCategory
 *  ic2.jeiIntegration.recipe.machine.IORecipeWrapper
 *  ic2.jeiIntegration.recipe.machine.IRecipeWrapperGenerator
 *  mezz.jei.api.BlankModPlugin
 *  mezz.jei.api.IGuiHelper
 *  mezz.jei.api.IJeiHelpers
 *  mezz.jei.api.IModRegistry
 *  mezz.jei.api.JEIPlugin
 *  mezz.jei.api.recipe.IRecipeCategory
 *  mezz.jei.api.recipe.IRecipeWrapper
 *  net.minecraft.item.ItemStack
 */
package com.chocohead.AdvMachines;

import com.chocohead.AdvMachines.AdvancedMachines;
import com.chocohead.AdvMachines.api.IDualMachineRecipeManager;
import com.chocohead.AdvMachines.te.AdvMachineTEs;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.api.recipe.IRecipeInput;
import ic2.api.recipe.RecipeOutput;
import ic2.core.block.BlockTileEntity;
import ic2.core.block.ITeBlock;
import ic2.core.ref.TeBlock;
import ic2.core.util.ReflectionUtil;
import ic2.jeiIntegration.recipe.machine.DynamicCategory;
import ic2.jeiIntegration.recipe.machine.IORecipeCategory;
import ic2.jeiIntegration.recipe.machine.IORecipeWrapper;
import ic2.jeiIntegration.recipe.machine.IRecipeWrapperGenerator;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import mezz.jei.api.BlankModPlugin;
import mezz.jei.api.IGuiHelper;
import mezz.jei.api.IJeiHelpers;
import mezz.jei.api.IModRegistry;
import mezz.jei.api.JEIPlugin;
import mezz.jei.api.recipe.IRecipeCategory;
import mezz.jei.api.recipe.IRecipeWrapper;
import net.minecraft.item.ItemStack;

@JEIPlugin
public final class JEICompat
extends BlankModPlugin {
    public IRecipeWrapperGenerator<IDualMachineRecipeManager> recipeWrapperGenerator;

    public JEICompat() {
        this.recipeWrapperGenerator = new IRecipeWrapperGenerator<IDualMachineRecipeManager>(){
            private final Field recipeManager;
            {
                this.recipeManager = ReflectionUtil.getField(IORecipeCategory.class, (String[])new String[]{"recipeManager"});
            }

            public List<IRecipeWrapper> getRecipeList(IORecipeCategory<IDualMachineRecipeManager> category) {
                ArrayList<IRecipeWrapper> recipes = new ArrayList<IRecipeWrapper>();
                for (IMachineRecipeManager.RecipeIoContainer container : ((IDualMachineRecipeManager)ReflectionUtil.getFieldValue((Field)this.recipeManager, category)).getExtraRecipes()) {
                    recipes.add((IRecipeWrapper)(new IORecipeWrapper(container.input, container.output, category){}));
                }
                return recipes;
            }

        };
    }

    public void register(IModRegistry registry) {
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.rotary_macerator), new String[]{TeBlock.macerator.getName()});
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.singularity_compressor), new String[]{TeBlock.compressor.getName()});
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.centrifuge_extractor), new String[]{TeBlock.extractor.getName()});
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.compacting_recycler), new String[]{TeBlock.recycler.getName()});
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.liquescent_extruder), new String[]{TeBlock.metal_former.getName() + '0'});
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.impellerized_roller), new String[]{TeBlock.metal_former.getName() + '1'});
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.water_jet_cutter), new String[]{TeBlock.metal_former.getName() + '2'});
        registry.addRecipeCategoryCraftingItem(AdvancedMachines.machines.getItemStack((ITeBlock)AdvMachineTEs.thermal_washer), new String[]{TeBlock.ore_washing_plant.getName()});
        IGuiHelper guiHelper = registry.getJeiHelpers().getGuiHelper();
        for (AdvMachineTEs te : AdvMachineTEs.values()) {
            for (String type : te.getRecipeCategories()) {
                this.addMachineRecipes(registry, (IORecipeCategory<T>)new DynamicCategory((ITeBlock)te, (Object)((IDualMachineRecipeManager)te.getManager(type)), guiHelper), (IRecipeWrapperGenerator<T>)this.recipeWrapperGenerator);
            }
        }
    }

    private <T> void addMachineRecipes(IModRegistry registry, IORecipeCategory<T> category, IRecipeWrapperGenerator<T> wrappergen) {
        List recipes = wrappergen.getRecipeList(category);
        if (!recipes.isEmpty()) {
            registry.addRecipeCategories(new IRecipeCategory[]{category});
            registry.addRecipes(recipes);
            registry.addRecipeCategoryCraftingItem(category.getBlockStack(), new String[]{category.getUid()});
        }
    }

}

