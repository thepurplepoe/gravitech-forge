/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockCrops
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package ic2.core.crop.cropcard;

import ic2.api.crops.CropProperties;
import ic2.core.crop.CropVanilla;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class CropCarrots
extends CropVanilla {
    public CropCarrots() {
        super((BlockCrops)Blocks.CARROTS);
    }

    @Override
    public String getId() {
        return "carrots";
    }

    @Override
    public int getMaxSize() {
        return 3;
    }

    @Override
    public CropProperties getProperties() {
        return new CropProperties(2, 0, 4, 0, 0, 2);
    }

    @Override
    public String[] getAttributes() {
        return new String[]{"Orange", "Food", "Carrots"};
    }

    @Override
    public ItemStack getProduct() {
        return new ItemStack(Items.CARROT);
    }

    @Override
    public ItemStack getSeeds() {
        return new ItemStack(Items.CARROT);
    }
}

