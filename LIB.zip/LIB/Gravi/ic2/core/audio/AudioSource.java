/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 */
package ic2.core.audio;

import net.minecraft.entity.player.EntityPlayer;

public class AudioSource {
    public void remove() {
    }

    public void play() {
    }

    public void pause() {
    }

    public void stop() {
    }

    public void flush() {
    }

    public float getVolume() {
        return 0.0f;
    }

    public void setVolume(float volume) {
    }

    public void setPitch(float pitch) {
    }

    public void updatePosition() {
    }

    public void activate() {
    }

    public void cull() {
    }

    public void updateVolume(EntityPlayer player) {
    }

    public float getRealVolume() {
        return 0.0f;
    }
}

