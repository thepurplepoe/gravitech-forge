/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.audio;

public enum PositionSpec {
    Center,
    Backpack,
    Hand;
    

    private PositionSpec() {
    }
}

