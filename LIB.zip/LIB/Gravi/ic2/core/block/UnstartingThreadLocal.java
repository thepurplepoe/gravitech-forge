/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block;

class UnstartingThreadLocal<T>
extends ThreadLocal<T> {
    UnstartingThreadLocal() {
    }

    @Override
    protected T initialValue() {
        throw new UnsupportedOperationException();
    }
}

