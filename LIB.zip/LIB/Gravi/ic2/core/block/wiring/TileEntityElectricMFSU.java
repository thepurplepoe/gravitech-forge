/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block.wiring;

import ic2.core.block.wiring.TileEntityElectricBlock;

public class TileEntityElectricMFSU
extends TileEntityElectricBlock {
    public TileEntityElectricMFSU() {
        super(4, 2048, 40000000);
    }
}

