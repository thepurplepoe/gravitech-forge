/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block.wiring;

import ic2.core.block.wiring.TileEntityElectricBlock;

public class TileEntityElectricBatBox
extends TileEntityElectricBlock {
    public TileEntityElectricBatBox() {
        super(1, 32, 40000);
    }
}

