/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block.wiring;

enum CableFoam {
    None,
    Soft,
    Hardened;
    
    public static final CableFoam[] values;

    private CableFoam() {
    }

    static {
        values = CableFoam.values();
    }
}

