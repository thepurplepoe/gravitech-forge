/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block.wiring;

import ic2.core.block.wiring.TileEntityTransformer;

public class TileEntityTransformerHV
extends TileEntityTransformer {
    public TileEntityTransformerHV() {
        super(3);
    }
}

