/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.NonNullList
 */
package ic2.core.block.wiring;

import ic2.core.block.wiring.TileEntityChargepadBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class TileEntityChargepadMFE
extends TileEntityChargepadBlock {
    public TileEntityChargepadMFE() {
        super(3, 512, 4000000);
    }

    @Override
    protected void getItems(EntityPlayer player) {
        if (player != null) {
            for (ItemStack current : player.inventory.armorInventory) {
                if (current == null) continue;
                this.chargeItem(current, 512);
            }
            for (ItemStack current : player.inventory.mainInventory) {
                if (current == null) continue;
                this.chargeItem(current, 512);
            }
        }
    }
}

