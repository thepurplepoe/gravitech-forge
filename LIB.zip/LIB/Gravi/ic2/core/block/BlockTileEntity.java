/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Function
 *  com.google.common.collect.ImmutableList
 *  net.minecraft.block.Block
 *  net.minecraft.block.SoundType
 *  net.minecraft.block.material.EnumPushReaction
 *  net.minecraft.block.material.MapColor
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.properties.PropertyDirection
 *  net.minecraft.block.state.BlockStateContainer
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.particle.ParticleManager
 *  net.minecraft.client.renderer.ItemMeshDefinition
 *  net.minecraft.client.renderer.block.model.ModelBakery
 *  net.minecraft.client.renderer.block.model.ModelResourceLocation
 *  net.minecraft.client.renderer.block.statemap.IStateMapper
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.EnumDyeColor
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.BlockRenderLayer
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumFacing$Axis
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.NonNullList
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.Explosion
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraft.world.WorldServer
 *  net.minecraftforge.client.model.ModelLoader
 *  net.minecraftforge.common.EnumPlantType
 *  net.minecraftforge.common.IPlantable
 *  net.minecraftforge.fml.common.Loader
 *  net.minecraftforge.fml.common.ModContainer
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package ic2.core.block;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableList;
import ic2.api.item.ITeBlockSpecialItem;
import ic2.api.tile.IWrenchable;
import ic2.core.CreativeTabIC2;
import ic2.core.IC2;
import ic2.core.Platform;
import ic2.core.block.BlockBase;
import ic2.core.block.ITeBlock;
import ic2.core.block.TeBlockRegistry;
import ic2.core.block.TileEntityBlock;
import ic2.core.block.UnstartingThreadLocal;
import ic2.core.block.state.IIdProvider;
import ic2.core.block.state.Ic2BlockState;
import ic2.core.block.state.MaterialProperty;
import ic2.core.block.state.SkippedBooleanProperty;
import ic2.core.init.MainConfig;
import ic2.core.item.block.ItemBlockTileEntity;
import ic2.core.model.ModelUtil;
import ic2.core.network.NetworkManager;
import ic2.core.ref.BlockName;
import ic2.core.ref.IBlockModelProvider;
import ic2.core.ref.IMultiBlock;
import ic2.core.ref.MetaTeBlock;
import ic2.core.ref.MetaTeBlockProperty;
import ic2.core.ref.TeBlock;
import ic2.core.util.ConfigUtil;
import ic2.core.util.Log;
import ic2.core.util.LogCategory;
import ic2.core.util.ParticleUtil;
import ic2.core.util.SideGateway;
import ic2.core.util.StackUtil;
import ic2.core.util.Util;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.renderer.ItemMeshDefinition;
import net.minecraft.client.renderer.block.model.ModelBakery;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.statemap.IStateMapper;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.EnumPlantType;
import net.minecraftforge.common.IPlantable;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public final class BlockTileEntity
extends BlockBase
implements IMultiBlock<ITeBlock>,
IWrenchable,
IPlantable {
    public final IProperty<MetaTeBlock> typeProperty;
    public final MaterialProperty materialProperty;
    public static final IProperty<EnumFacing> facingProperty = PropertyDirection.create((String)"facing");
    private static final ThreadLocal<IProperty<MetaTeBlock>> currentTypeProperty = new UnstartingThreadLocal<IProperty<MetaTeBlock>>();
    private static final ThreadLocal<MaterialProperty> currentMaterialProperty = new UnstartingThreadLocal<MaterialProperty>();
    public static final IProperty<Boolean> transparentProperty = new SkippedBooleanProperty("transparent");
    private final ItemBlockTileEntity item;
    private static final int removedTesToKeep = 4;
    private static final WeakReference<TileEntityBlock>[] removedTes = new WeakReference[4];
    private static int nextRemovedTeIndex;

    static BlockTileEntity create(BlockName name, Collection<Material> materials) {
        BlockTileEntity ret = BlockTileEntity.create(name.name(), TeBlock.invalid.getIdentifier(), materials);
        name.setInstance(ret);
        return ret;
    }

    static BlockTileEntity create(String name, ResourceLocation identifier, Collection<Material> materials) {
        currentTypeProperty.set(new MetaTeBlockProperty(identifier));
        currentMaterialProperty.set(new MaterialProperty(materials));
        BlockTileEntity ret = new BlockTileEntity(name, identifier);
        currentMaterialProperty.remove();
        currentTypeProperty.remove();
        return ret;
    }

    private BlockTileEntity(String name, final ResourceLocation identifier) {
        super(null, Material.IRON);
        this.typeProperty = this.getTypeProperty();
        this.materialProperty = this.getMaterialProperty();
        ModContainer ic2 = Loader.instance().activeModContainer();
        Loader.instance().getActiveModList().stream().filter(mod -> identifier.getResourceDomain().equals(mod.getModId())).findFirst().ifPresent(mod -> {
            Loader.instance().setActiveModContainer(mod);
        }
        );
        this.register(name, identifier, (java.util.function.Function<Block, Item>)new Function<Block, Item>(){

            public Item apply(Block input) {
                return new ItemBlockTileEntity(input, identifier);
            }
        });
        Loader.instance().setActiveModContainer(ic2);
        this.setDefaultState(this.blockState.getBaseState().withProperty((IProperty)this.materialProperty, (Comparable)MaterialProperty.WrappedMaterial.IRON).withProperty(this.typeProperty, (Comparable)MetaTeBlockProperty.invalid).withProperty(facingProperty, (Comparable)EnumFacing.DOWN).withProperty(transparentProperty, (Comparable)Boolean.FALSE));
        this.item = (ItemBlockTileEntity)Item.getItemFromBlock((Block)this);
        IC2.log.debug(LogCategory.Block, "Successfully built BlockTileEntity for identity " + (Object)identifier + '.');
    }

    @SideOnly(value=Side.CLIENT)
    @Override
    public void registerModels(BlockName name) {
        final ModelResourceLocation invalidLocation = ModelUtil.getTEBlockModelLocation(Util.getName(BlockName.te.getInstance()), this.blockState.getBaseState().withProperty((IProperty)this.materialProperty, (Comparable)MaterialProperty.WrappedMaterial.IRON).withProperty(this.typeProperty, (Comparable)MetaTeBlockProperty.invalid).withProperty(facingProperty, (Comparable)EnumFacing.NORTH).withProperty(transparentProperty, (Comparable)Boolean.FALSE));
        IC2.log.debug(LogCategory.Block, "Preparing to set models for " + (Object)this.item.identifier + '.');
        IC2.log.debug(LogCategory.Block, "Mapping " + this.getBlockState().getValidStates().size() + " states.");
        ModelLoader.setCustomStateMapper((Block)this, (IStateMapper)new IStateMapper(){

            public Map<IBlockState, ModelResourceLocation> putStateModelLocations(Block block) {
                IdentityHashMap<IBlockState, ModelResourceLocation> ret = new IdentityHashMap<IBlockState, ModelResourceLocation>();
                for (IBlockState state : block.getBlockState().getValidStates()) {
                    MetaTeBlock metaTeBlock = (MetaTeBlock)state.getValue(BlockTileEntity.this.typeProperty);
                    EnumFacing facing = (EnumFacing)state.getValue(BlockTileEntity.facingProperty);
                    if (metaTeBlock.teBlock.getSupportedFacings().contains((Object)facing) || facing == EnumFacing.DOWN && metaTeBlock.teBlock.getSupportedFacings().isEmpty()) {
                        ret.put(state, ModelUtil.getTEBlockModelLocation(metaTeBlock.teBlock.getIdentifier(), state));
                        continue;
                    }
                    ret.put(state, invalidLocation);
                }
                return ret;
            }
        });
        ModelLoader.setCustomMeshDefinition((Item)this.item, (ItemMeshDefinition)new ItemMeshDefinition(){

            public ModelResourceLocation getModelLocation(ItemStack stack) {
                ITeBlock teBlock = TeBlockRegistry.get(BlockTileEntity.access$000((BlockTileEntity)BlockTileEntity.this).identifier, stack.getItemDamage());
                if (teBlock == null) {
                    return invalidLocation;
                }
                if (teBlock instanceof ITeBlockSpecialItem && ((ITeBlockSpecialItem)((Object)teBlock)).doesOverrideDefault(stack)) {
                    ModelResourceLocation location = ((ITeBlockSpecialItem)((Object)teBlock)).getModelLocation(stack);
                    return location == null ? invalidLocation : location;
                }
                IBlockState state = BlockTileEntity.this.getDefaultState().withProperty(BlockTileEntity.this.typeProperty, (Comparable)MetaTeBlockProperty.getState(teBlock)).withProperty(BlockTileEntity.facingProperty, (Comparable)EnumFacing.NORTH);
                return ModelUtil.getTEBlockModelLocation(teBlock.getIdentifier(), state);
            }
        });
        boolean checkSpecialModels = TeBlockRegistry.getInfo(this.item.identifier).hasSpecialModels();
        for (MetaTeBlockProperty.MetaTePair block : MetaTeBlockProperty.getAllStates(this.item.identifier)) {
            if (block.hasItem()) {
                ModelResourceLocation model;
                ModelResourceLocation modelResourceLocation = model = checkSpecialModels ? this.getSpecialModel(block) : null;
                if (model == null) {
                    IBlockState state = this.blockState.getBaseState().withProperty(this.typeProperty, (Comparable)block.inactive).withProperty(facingProperty, (Comparable)EnumFacing.NORTH);
                    model = ModelUtil.getTEBlockModelLocation(block.getIdentifier(), state);
                }
                assert (model != null);
                ModelBakery.registerItemVariants((Item)this.item, (ResourceLocation[])new ResourceLocation[]{model});
            }
            IC2.log.debug(LogCategory.Block, "Done item for " + (Object)this.item.identifier + ':' + block.getName() + '.');
        }
    }

    @SideOnly(value=Side.CLIENT)
    private ModelResourceLocation getSpecialModel(MetaTeBlockProperty.MetaTePair blockTextures) {
        ItemStack stack;
        assert (blockTextures.getBlock() instanceof ITeBlockSpecialItem);
        ITeBlockSpecialItem block = (ITeBlockSpecialItem)((Object)blockTextures.getBlock());
        return block.doesOverrideDefault(stack = new ItemStack((Item)this.item, 1, blockTextures.getBlock().getId())) ? block.getModelLocation(stack) : null;
    }

    public boolean canRenderInLayer(IBlockState state, BlockRenderLayer layer) {
        return ((Boolean)state.getValue(transparentProperty)).booleanValue() ? layer == BlockRenderLayer.CUTOUT : layer == BlockRenderLayer.SOLID;
    }

    public boolean hasTileEntity() {
        return true;
    }

    public boolean hasTileEntity(IBlockState state) {
        return true;
    }

    protected BlockStateContainer createBlockState() {
        return new Ic2BlockState(this, new IProperty[]{this.getTypeProperty(), this.getMaterialProperty(), facingProperty, transparentProperty});
    }

    public int getMetaFromState(IBlockState state) {
        int ret = this.materialProperty.getId((MaterialProperty.WrappedMaterial)state.getValue((IProperty)this.materialProperty));
        if (ret < 0 || ret >= 8) {
            throw new IllegalStateException("invalid material id: " + ret);
        }
        return ret |= (Boolean)state.getValue(transparentProperty) != false ? 8 : 0;
    }

    public IBlockState getStateFromMeta(int meta) {
        boolean isTransparent = (meta & 8) != 0;
        int materialId = meta & 7;
        return this.getDefaultState().withProperty((IProperty)this.materialProperty, (Comparable)this.materialProperty.getMaterial(materialId)).withProperty(transparentProperty, (Comparable)Boolean.valueOf(isTransparent));
    }

    public IBlockState getActualState(IBlockState state, IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return state;
        }
        return te.getBlockState();
    }

    @Override
    public String getUnlocalizedName() {
        if (!this.isIC2()) {
            return this.item.identifier.getResourceDomain() + '.' + this.item.identifier.getResourcePath();
        }
        return super.getUnlocalizedName();
    }

    @SideOnly(value=Side.CLIENT)
    public void getSubBlocks(CreativeTabs tabs, NonNullList<ItemStack> list) {
        TeBlockRegistry.TeBlockInfo info = TeBlockRegistry.getInfo(this.item.identifier);
        if (info.hasCreativeRegisterer()) {
            info.getCreativeRegisterer().addSubBlocks(list, this, this.item, tabs);
        } else if (tabs == IC2.tabIC2 || tabs == CreativeTabs.SEARCH) {
            for (ITeBlock type : info.getTeBlocks()) {
                if (!type.hasItem()) continue;
                list.add((Object)this.getItemStack(type));
            }
        }
    }

    @Override
    public Set<ITeBlock> getAllTypes() {
        return Collections.unmodifiableSet(TeBlockRegistry.getAll(this.item.identifier));
    }

    @Override
    public Set<ItemStack> getAllStacks() {
        HashSet<ItemStack> ret = new HashSet<ItemStack>();
        for (ITeBlock block : TeBlockRegistry.getItems(this.item.identifier)) {
            ret.add(this.getItemStack(block));
        }
        return ret;
    }

    public ItemStack getItem(World world, BlockPos pos, IBlockState state) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return ItemStack.EMPTY;
        }
        return te.getPickBlock(null, null);
    }

    public ItemStack getPickBlock(IBlockState state, RayTraceResult target, World world, BlockPos pos, EntityPlayer player) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return ItemStack.EMPTY;
        }
        return te.getPickBlock(player, target);
    }

    @Override
    public IBlockState getState(ITeBlock variant) {
        if (variant == null) {
            throw new IllegalArgumentException("invalid type: " + variant);
        }
        Set<EnumFacing> supportedFacings = variant.getSupportedFacings();
        EnumFacing facing = supportedFacings.isEmpty() ? EnumFacing.DOWN : (supportedFacings.contains((Object)EnumFacing.NORTH) ? EnumFacing.NORTH : supportedFacings.iterator().next());
        return this.getDefaultState().withProperty((IProperty)this.materialProperty, (Comparable)MaterialProperty.WrappedMaterial.get(variant.getMaterial())).withProperty(this.typeProperty, (Comparable)MetaTeBlockProperty.getState(variant)).withProperty(facingProperty, (Comparable)facing).withProperty(transparentProperty, (Comparable)Boolean.valueOf(variant.isTransparent()));
    }

    @Override
    public IBlockState getState(String variant) {
        return this.getState(TeBlockRegistry.get(variant));
    }

    @Override
    public ItemStack getItemStack(ITeBlock type) {
        if (type == null) {
            throw new IllegalArgumentException("invalid type: null");
        }
        int id = type.getId();
        if (id != -1) {
            return new ItemStack((Item)this.item, 1, id);
        }
        return null;
    }

    @Override
    public ItemStack getItemStack(String variant) {
        if (variant == null) {
            throw new IllegalArgumentException("Invalid ITeBlock type: null");
        }
        ITeBlock type = TeBlockRegistry.get(variant);
        if (type == null) {
            throw new IllegalArgumentException("Invalid ITeBlock type: " + variant);
        }
        return this.getItemStack(type);
    }

    @Override
    public String getVariant(ItemStack stack) {
        if (stack == null) {
            throw new NullPointerException("null stack");
        }
        if (stack.getItem() != this.item) {
            throw new IllegalArgumentException("The stack " + (Object)stack + " doesn't match " + (Object)((Object)this.item) + " (" + this + ")");
        }
        ITeBlock type = TeBlockRegistry.get(this.item.identifier, stack.getMetadata());
        if (type == null) {
            throw new IllegalArgumentException("The stack " + (Object)stack + " doesn't reference any valid subtype");
        }
        return type.getName();
    }

    public boolean isFullCube(IBlockState state) {
        return false;
    }

    public boolean isOpaqueCube(IBlockState state) {
        return (Boolean)state.getValue(transparentProperty) == false;
    }

    public boolean canReplace(World world, BlockPos pos, EnumFacing side, ItemStack stack) {
        if (StackUtil.isEmpty(stack)) {
            return true;
        }
        if (stack.getItem() != this.item) {
            return false;
        }
        ITeBlock type = TeBlockRegistry.get(this.item.identifier, stack.getMetadata());
        if (type == null) {
            return false;
        }
        TeBlock.ITePlaceHandler handler = type.getPlaceHandler();
        return handler == null || handler.canReplace(world, pos, side, stack);
    }

    public boolean addLandingEffects(IBlockState state, WorldServer world, BlockPos pos, IBlockState state2, EntityLivingBase entity, int numberOfParticles) {
        if (world.isRemote) {
            throw new IllegalStateException();
        }
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return super.addLandingEffects(state, world, pos, state2, entity, numberOfParticles);
        }
        IC2.network.get(true).initiateTeblockLandEffect((World)world, entity.posX, entity.posY, entity.posZ, numberOfParticles, te.teBlock);
        return true;
    }

    @SideOnly(value=Side.CLIENT)
    public boolean addHitEffects(IBlockState state, World world, RayTraceResult target, ParticleManager manager) {
        BlockPos pos = target.getBlockPos();
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return super.addHitEffects(state, world, target, manager);
        }
        ParticleUtil.spawnBlockHitParticles(te, target.sideHit);
        return true;
    }

    @SideOnly(value=Side.CLIENT)
    public boolean addDestroyEffects(World world, BlockPos pos, ParticleManager manager) {
        return super.addDestroyEffects(world, pos, manager);
    }

    public Material getMaterial(IBlockState state) {
        return ((MaterialProperty.WrappedMaterial)state.getValue((IProperty)this.materialProperty)).getMaterial();
    }

    public boolean causesSuffocation(IBlockState state) {
        return this.getMaterial(state).blocksMovement() && this.getDefaultState().isFullCube();
    }

    public boolean isPassable(IBlockAccess world, BlockPos pos) {
        return !this.getMaterial(world.getBlockState(pos)).blocksMovement();
    }

    public boolean canSpawnInBlock() {
        return super.canSpawnInBlock();
    }

    public EnumPushReaction getMobilityFlag(IBlockState state) {
        return this.getMaterial(state).getMobilityFlag();
    }

    public boolean isTranslucent(IBlockState state) {
        return !this.getMaterial(state).blocksLight();
    }

    public MapColor getMapColor(IBlockState state, IBlockAccess world, BlockPos pos) {
        return this.getMaterial(state).getMaterialMapColor();
    }

    public IBlockState getExtendedState(IBlockState state, IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return state;
        }
        return te.getExtendedState((Ic2BlockState.Ic2BlockStateInstance)state);
    }

    public void onBlockPlacedBy(World world, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return;
        }
        te.onPlaced(stack, placer, EnumFacing.UP);
    }

    public RayTraceResult collisionRayTrace(IBlockState state, World world, BlockPos pos, Vec3d start, Vec3d end) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return super.collisionRayTrace(state, world, pos, start, end);
        }
        return te.collisionRayTrace(start, end);
    }

    public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return super.getBoundingBox(state, world, pos);
        }
        return te.getVisualBoundingBox();
    }

    public AxisAlignedBB getSelectedBoundingBox(IBlockState state, World world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return super.getSelectedBoundingBox(state, world, pos);
        }
        return te.getOutlineBoundingBox().offset(pos);
    }

    public AxisAlignedBB getCollisionBoundingBox(IBlockState state, IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return super.getCollisionBoundingBox(state, world, pos);
        }
        return te.getPhysicsBoundingBox();
    }

    public void addCollisionBoxToList(IBlockState state, World world, BlockPos pos, AxisAlignedBB mask, List<AxisAlignedBB> list, Entity collidingEntity, boolean isActualState) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            super.addCollisionBoxToList(state, world, pos, mask, list, collidingEntity, isActualState);
        } else {
            te.addCollisionBoxesToList(mask, list, collidingEntity);
        }
    }

    public void onEntityCollidedWithBlock(World world, BlockPos pos, IBlockState state, Entity entity) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return;
        }
        te.onEntityCollision(entity);
    }

    @SideOnly(value=Side.CLIENT)
    public boolean shouldSideBeRendered(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing side) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return super.shouldSideBeRendered(state, world, pos, side);
        }
        return te.shouldSideBeRendered(side, pos.offset(side));
    }

    public boolean doesSideBlockRendering(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing face) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return false;
        }
        return te.doesSideBlockRendering(face);
    }

    public boolean isNormalCube(IBlockState state, IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return false;
        }
        return te.isNormalCube();
    }

    public boolean isSideSolid(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing side) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return false;
        }
        return te.isSideSolid(side);
    }

    public int getLightOpacity(IBlockState state, IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return this.getLightOpacity(state);
        }
        return te.getLightOpacity();
    }

    public int getLightValue(IBlockState state, IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return 0;
        }
        return te.getLightValue();
    }

    public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing side, float hitX, float hitY, float hitZ) {
        if (player.isSneaking()) {
            return false;
        }
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return false;
        }
        return te.onActivated(player, hand, side, hitX, hitY, hitZ);
    }

    public void onBlockClicked(World world, BlockPos pos, EntityPlayer player) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return;
        }
        te.onClicked(player);
    }

    public void neighborChanged(IBlockState state, World world, BlockPos pos, Block neighborBlock, BlockPos neighborPos) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return;
        }
        te.onNeighborChange(neighborBlock, neighborPos);
    }

    public int getStrongPower(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing side) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return 0;
        }
        return te.getStrongPower(side);
    }

    public int getWeakPower(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing side) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return 0;
        }
        return te.getWeakPower(side);
    }

    public boolean canConnectRedstone(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing side) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return false;
        }
        return te.connectRedstone(side);
    }

    public boolean hasComparatorInputOverride(IBlockState state) {
        return true;
    }

    public int getComparatorInputOverride(IBlockState state, World world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return 0;
        }
        return te.getComparatorInputOverride();
    }

    public boolean recolorBlock(World world, BlockPos pos, EnumFacing side, EnumDyeColor color) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return false;
        }
        return te.recolor(side, color);
    }

    public void onBlockExploded(World world, BlockPos pos, Explosion explosion) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te != null) {
            te.onExploded(explosion);
        }
        super.onBlockExploded(world, pos, explosion);
    }

    public void breakBlock(World world, BlockPos pos, IBlockState state) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te != null) {
            te.onBlockBreak();
        }
        super.breakBlock(world, pos, state);
    }

    public boolean removedByPlayer(IBlockState state, World world, BlockPos pos, EntityPlayer player, boolean willHarvest) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te != null) {
            if (!te.onRemovedByPlayer(player, willHarvest)) {
                return false;
            }
            if (willHarvest && !world.isRemote) {
                BlockTileEntity.removedTes[BlockTileEntity.nextRemovedTeIndex] = new WeakReference<TileEntityBlock>(te);
                nextRemovedTeIndex = (nextRemovedTeIndex + 1) % 4;
            }
        }
        return super.removedByPlayer(state, world, pos, player, willHarvest);
    }

    public float getPlayerRelativeBlockHardness(IBlockState state, EntityPlayer player, World world, BlockPos pos) {
        TileEntityBlock te;
        float ret = super.getPlayerRelativeBlockHardness(state, player, world, pos);
        if (!player.canHarvestBlock(state) && (te = BlockTileEntity.getTe((IBlockAccess)world, pos)) != null && te.teBlock.getHarvestTool() == TeBlock.HarvestTool.None) {
            ret *= 3.3333333f;
        }
        return ret;
    }

    public boolean canHarvestBlock(IBlockAccess world, BlockPos pos, EntityPlayer player) {
        boolean ret = super.canHarvestBlock(world, pos, player);
        if (ret) {
            return ret;
        }
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te != null && te.teBlock.getHarvestTool() == TeBlock.HarvestTool.None) {
            return true;
        }
        return false;
    }

    public String getHarvestTool(IBlockState state) {
        if (state.getBlock() != this) {
            return null;
        }
        return ((MetaTeBlock)state.getValue(this.typeProperty)).teBlock.getHarvestTool().toolClass;
    }

    public int getHarvestLevel(IBlockState state) {
        if (state.getBlock() != this) {
            return 0;
        }
        return ((MetaTeBlock)state.getValue(this.typeProperty)).teBlock.getHarvestTool().level;
    }

    public void getDrops(NonNullList<ItemStack> list, IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
        list.addAll(this.getDrops(world, pos, state, fortune));
    }

    public List<ItemStack> getDrops(IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            int checkIdx;
            World realWorld = Util.getWorld(world);
            if (realWorld != null && realWorld.isRemote || realWorld == null && !IC2.platform.isSimulating()) {
                return new ArrayList<ItemStack>();
            }
            int idx = nextRemovedTeIndex;
            do {
                TileEntityBlock cTe;
                WeakReference<TileEntityBlock> ref;
                if ((ref = removedTes[checkIdx = (idx + 4 - 1) % 4]) == null || (cTe = ref.get()) == null || realWorld != null && cTe.getWorld() != realWorld || !cTe.getPos().equals((Object)pos)) continue;
                te = cTe;
                BlockTileEntity.removedTes[checkIdx] = null;
                break;
            } while ((idx = checkIdx) != nextRemovedTeIndex);
            if (te == null) {
                return new ArrayList<ItemStack>();
            }
        }
        ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
        ret.addAll(te.getSelfDrops(fortune, ConfigUtil.getBool(MainConfig.get(), "balance/ignoreWrenchRequirement")));
        ret.addAll(te.getAuxDrops(fortune));
        return ret;
    }

    public float getBlockHardness(IBlockState state, World world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return 5.0f;
        }
        return te.getHardness();
    }

    public float getExplosionResistance(World world, BlockPos pos, Entity exploder, Explosion explosion) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return 10.0f;
        }
        return te.getExplosionResistance(exploder, explosion);
    }

    public boolean canEntityDestroy(IBlockState state, IBlockAccess world, BlockPos pos, Entity entity) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return true;
        }
        return te.canEntityDestroy(entity);
    }

    @Override
    public EnumFacing getFacing(World world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return EnumFacing.DOWN;
        }
        return te.getFacing();
    }

    @Override
    public boolean setFacing(World world, BlockPos pos, EnumFacing newDirection, EntityPlayer player) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return false;
        }
        return te.setFacingWrench(newDirection, player);
    }

    @Override
    public boolean wrenchCanRemove(World world, BlockPos pos, EntityPlayer player) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return false;
        }
        return te.wrenchCanRemove(player);
    }

    @Override
    public List<ItemStack> getWrenchDrops(World world, BlockPos pos, IBlockState state, TileEntity te, EntityPlayer player, int fortune) {
        if (!(te instanceof TileEntityBlock)) {
            return Collections.emptyList();
        }
        return ((TileEntityBlock)te).getWrenchDrops(player, fortune);
    }

    public EnumPlantType getPlantType(IBlockAccess world, BlockPos pos) {
        TileEntityBlock te = BlockTileEntity.getTe(world, pos);
        if (te == null) {
            return TileEntityBlock.noCrop;
        }
        return te.getPlantType();
    }

    public SoundType getSoundType(IBlockState state, World world, BlockPos pos, Entity entity) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te == null) {
            return super.getSoundType(state, world, pos, entity);
        }
        return te.getBlockSound(entity);
    }

    private static TileEntityBlock getTe(IBlockAccess world, BlockPos pos) {
        TileEntity te = world.getTileEntity(pos);
        if (te instanceof TileEntityBlock) {
            return (TileEntityBlock)te;
        }
        return null;
    }

    public IBlockState getPlant(IBlockAccess world, BlockPos pos) {
        return world.getBlockState(pos);
    }

    public boolean rotateBlock(World world, BlockPos pos, EnumFacing axis) {
        TileEntityBlock te = BlockTileEntity.getTe((IBlockAccess)world, pos);
        if (te != null) {
            EnumFacing target = te.getFacing().rotateAround(axis.getAxis());
            if (te.getSupportedFacings().contains((Object)target) && te.getFacing() != target) {
                te.setFacing(target);
                return true;
            }
        }
        return false;
    }

    public boolean isIC2() {
        return this.item.identifier == TeBlock.invalid.getIdentifier();
    }

    public ItemBlockTileEntity getItem() {
        return this.item;
    }

    public final IProperty<MetaTeBlock> getTypeProperty() {
        IProperty<MetaTeBlock> ret;
        IProperty<MetaTeBlock> iProperty = ret = this.typeProperty != null ? this.typeProperty : currentTypeProperty.get();
        assert (ret != null);
        return ret;
    }

    public final MaterialProperty getMaterialProperty() {
        MaterialProperty ret;
        MaterialProperty materialProperty = ret = this.materialProperty != null ? this.materialProperty : currentMaterialProperty.get();
        assert (ret != null);
        return ret;
    }

    static /* synthetic */ ItemBlockTileEntity access$000(BlockTileEntity x0) {
        return x0.item;
    }

}

