/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block;

public abstract class RenderBlock {
}

