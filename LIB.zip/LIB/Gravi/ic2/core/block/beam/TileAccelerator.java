/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumFacing$Axis
 *  net.minecraft.util.math.AxisAlignedBB
 */
package ic2.core.block.beam;

import ic2.core.block.machine.tileentity.TileEntityElectricMachine;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;

public class TileAccelerator
extends TileEntityElectricMachine {
    private static final Map<EnumFacing.Axis, List<AxisAlignedBB>> FACING_AABBs = TileAccelerator.makeAABBMap();

    public TileAccelerator() {
        super(5000, 2);
    }

    @Override
    protected List<AxisAlignedBB> getAabbs(boolean forCollision) {
        return FACING_AABBs.get((Object)this.getFacing().getAxis());
    }

    @Override
    protected int getLightOpacity() {
        return 0;
    }

    private static Map<EnumFacing.Axis, List<AxisAlignedBB>> makeAABBMap() {
        EnumMap<EnumFacing.Axis, List<AxisAlignedBB>> ret = new EnumMap<EnumFacing.Axis, List<AxisAlignedBB>>(EnumFacing.Axis.class);
        ret.put(EnumFacing.Axis.X, Collections.singletonList(new AxisAlignedBB(0.0, 0.0, 0.25, 1.0, 1.0, 0.75)));
        ret.put(EnumFacing.Axis.Y, Collections.singletonList(new AxisAlignedBB(0.0, 0.25, 0.0, 1.0, 0.75, 1.0)));
        ret.put(EnumFacing.Axis.Z, Collections.singletonList(new AxisAlignedBB(0.25, 0.0, 0.0, 0.75, 1.0, 1.0)));
        return ret;
    }
}

