/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.SoundType
 */
package ic2.core.block.type;

import net.minecraft.block.SoundType;

public interface IBlockSound {
    public SoundType getSound();
}

