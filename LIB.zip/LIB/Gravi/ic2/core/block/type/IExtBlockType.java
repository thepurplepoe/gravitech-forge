/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block.type;

public interface IExtBlockType {
    public float getHardness();

    public float getExplosionResistance();
}

