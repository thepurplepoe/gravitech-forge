/*
 * Decompiled with CFR 0_124.
 */
package ic2.core.block.state;

public interface IIdProvider {
    public String getName();

    public int getId();
}

