/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.world.World
 */
package ic2.core.block.reactor.tileentity;

import ic2.core.block.TileEntityBlock;
import ic2.core.block.comp.FluidReactorLookup;
import ic2.core.block.comp.Redstone;
import ic2.core.block.comp.TileEntityComponent;
import ic2.core.block.reactor.tileentity.TileEntityNuclearReactorElectric;
import ic2.core.block.reactor.tileentity.TileEntityReactorVessel;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class TileEntityReactorRedstonePort
extends TileEntityReactorVessel {
    public final Redstone redstone;

    public TileEntityReactorRedstonePort() {
        this.redstone = this.addComponent(new Redstone(this));
    }

    @Override
    protected void onLoaded() {
        super.onLoaded();
        this.updateRedstoneLink();
    }

    private void updateRedstoneLink() {
        if (this.getWorld().isRemote) {
            return;
        }
        TileEntityNuclearReactorElectric reactor = this.lookup.getReactor();
        if (reactor != null) {
            this.redstone.linkTo(reactor.redstone);
        }
    }

    @Override
    protected boolean connectRedstone(EnumFacing side) {
        return true;
    }
}

