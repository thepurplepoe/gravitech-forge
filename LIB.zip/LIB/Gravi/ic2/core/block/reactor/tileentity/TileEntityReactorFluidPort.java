/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Supplier
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package ic2.core.block.reactor.tileentity;

import com.google.common.base.Supplier;
import ic2.api.reactor.IReactor;
import ic2.api.reactor.IReactorChamber;
import ic2.api.upgrade.IUpgradableBlock;
import ic2.api.upgrade.UpgradableProperty;
import ic2.core.ContainerBase;
import ic2.core.IHasGui;
import ic2.core.block.TileEntityBlock;
import ic2.core.block.TileEntityInventory;
import ic2.core.block.comp.FluidReactorLookup;
import ic2.core.block.comp.Fluids;
import ic2.core.block.comp.TileEntityComponent;
import ic2.core.block.invslot.InvSlotUpgrade;
import ic2.core.block.reactor.container.ContainerReactorFluidPort;
import ic2.core.block.reactor.gui.GuiReactorFluidPort;
import ic2.core.block.reactor.tileentity.TileEntityNuclearReactorElectric;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TileEntityReactorFluidPort
extends TileEntityInventory
implements IHasGui,
IUpgradableBlock,
IReactorChamber {
    public final InvSlotUpgrade upgradeSlot;
    private final FluidReactorLookup lookup;
    protected final Fluids fluids;

    public TileEntityReactorFluidPort() {
        this.upgradeSlot = new InvSlotUpgrade(this, "upgrade", 1);
        this.lookup = this.addComponent(new FluidReactorLookup(this));
        this.fluids = this.addComponent(new Fluids(this));
        this.fluids.addUnmanagedTankHook(new Supplier<Collection<Fluids.InternalFluidTank>>(){

            public Collection<Fluids.InternalFluidTank> get() {
                TileEntityNuclearReactorElectric reactor = TileEntityReactorFluidPort.this.getReactorInstance();
                if (reactor == null) {
                    return Collections.emptySet();
                }
                return Arrays.asList(new Fluids.InternalFluidTank[]{reactor.inputTank, reactor.outputTank});
            }
        });
    }

    @Override
    protected void updateEntityServer() {
        super.updateEntityServer();
        this.upgradeSlot.tick();
    }

    public ContainerBase<TileEntityReactorFluidPort> getGuiContainer(EntityPlayer player) {
        return new ContainerReactorFluidPort(player, this);
    }

    @SideOnly(value=Side.CLIENT)
    @Override
    public GuiScreen getGui(EntityPlayer player, boolean isAdmin) {
        return new GuiReactorFluidPort(new ContainerReactorFluidPort(player, this));
    }

    @Override
    public void onGuiClosed(EntityPlayer player) {
    }

    @Override
    public Set<UpgradableProperty> getUpgradableProperties() {
        return EnumSet.of(UpgradableProperty.FluidConsuming, UpgradableProperty.FluidProducing);
    }

    @Override
    public double getEnergy() {
        return 40.0;
    }

    @Override
    public boolean useEnergy(double amount) {
        return true;
    }

    @Override
    public TileEntityNuclearReactorElectric getReactorInstance() {
        return this.lookup.getReactor();
    }

    @Override
    public boolean isWall() {
        return true;
    }

}

