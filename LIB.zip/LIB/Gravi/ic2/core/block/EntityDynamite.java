/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.IProjectile
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 */
package ic2.core.block;

import ic2.core.PointExplosion;
import ic2.core.util.Util;
import ic2.core.util.Vector3;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityDynamite
extends Entity
implements IProjectile {
    public boolean sticky = false;
    public static final int netId = 142;
    public BlockPos stickPos;
    public int fuse = 100;
    private boolean inGround = false;
    public EntityLivingBase owner;
    private int ticksInGround;

    public EntityDynamite(World world, double x, double y, double z) {
        super(world);
        this.setSize(0.5f, 0.5f);
        this.setPosition(x, y, z);
    }

    public EntityDynamite(World world) {
        this(world, 0.0, 0.0, 0.0);
    }

    public EntityDynamite(World world, EntityLivingBase owner) {
        super(world);
        this.owner = owner;
        this.setSize(0.5f, 0.5f);
        Vector3 eyePos = Util.getEyePosition((Entity)owner);
        this.setLocationAndAngles(eyePos.x, eyePos.y, eyePos.z, owner.rotationYaw, owner.rotationPitch);
        this.posX -= Math.cos(Math.toRadians(this.rotationYaw)) * 0.16;
        this.posY -= 0.1;
        this.posZ -= Math.sin(Math.toRadians(this.rotationYaw)) * 0.16;
        this.setPosition(this.posX, this.posY, this.posZ);
        this.motionX = (- Math.sin(Math.toRadians(this.rotationYaw))) * Math.cos(Math.toRadians(this.rotationPitch));
        this.motionZ = Math.cos(Math.toRadians(this.rotationYaw)) * Math.cos(Math.toRadians(this.rotationPitch));
        this.motionY = - Math.sin(Math.toRadians(this.rotationPitch));
        this.setThrowableHeading(this.motionX, this.motionY, this.motionZ, 1.0f, 1.0f);
    }

    protected void entityInit() {
    }

    public void setThrowableHeading(double x, double y, double z, float velocity, float inaccuracy) {
        double len = Math.sqrt(x * x + y * y + z * z);
        x /= len;
        y /= len;
        z /= len;
        x += this.rand.nextGaussian() * 0.0075 * (double)inaccuracy;
        y += this.rand.nextGaussian() * 0.0075 * (double)inaccuracy;
        z += this.rand.nextGaussian() * 0.0075 * (double)inaccuracy;
        this.motionX = x *= (double)velocity;
        this.motionY = y *= (double)velocity;
        this.motionZ = z *= (double)velocity;
        double hLen = Math.sqrt(x * x + z * z);
        this.prevRotationYaw = this.rotationYaw = (float)(Math.atan2(x, z) * 180.0 / 3.141592653589793);
        this.prevRotationPitch = this.rotationPitch = (float)(Math.atan2(y, hLen) * 180.0 / 3.141592653589793);
        this.ticksInGround = 0;
    }

    public void setVelocity(double x, double y, double z) {
        this.motionX = x;
        this.motionY = y;
        this.motionZ = z;
        if (this.prevRotationPitch == 0.0f && this.prevRotationYaw == 0.0f) {
            double h = Math.sqrt(x * x + z * z);
            this.prevRotationYaw = this.rotationYaw = (float)(Math.atan2(x, z) * 180.0 / 3.141592653589793);
            this.prevRotationPitch = this.rotationPitch = (float)(Math.atan2(y, h) * 180.0 / 3.141592653589793);
            this.prevRotationPitch = this.rotationPitch;
            this.prevRotationYaw = this.rotationYaw;
            this.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
            this.ticksInGround = 0;
        }
    }

    public void onUpdate() {
        RayTraceResult result;
        Vec3d start;
        Vec3d end;
        super.onUpdate();
        if (this.prevRotationPitch == 0.0f && this.prevRotationYaw == 0.0f) {
            double hLen = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            this.prevRotationYaw = this.rotationYaw = (float)Math.toDegrees(Math.atan2(this.motionX, this.motionZ));
            this.prevRotationPitch = this.rotationPitch = (float)Math.toDegrees(Math.atan2(this.motionY, hLen));
        }
        World world = this.getEntityWorld();
        if (this.fuse-- <= 0) {
            this.setDead();
            if (!world.isRemote) {
                this.explode();
            }
        } else if (this.fuse < 100 && this.fuse % 2 == 0) {
            world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, this.posX, this.posY + 0.5, this.posZ, 0.0, 0.0, 0.0, new int[0]);
        }
        if (this.inGround) {
            ++this.ticksInGround;
            if (this.ticksInGround >= 200) {
                this.setDead();
            }
            if (this.sticky) {
                this.fuse -= 3;
                this.motionX = 0.0;
                this.motionY = 0.0;
                this.motionZ = 0.0;
                if (!world.isAirBlock(this.stickPos)) {
                    return;
                }
            }
        }
        if ((result = world.rayTraceBlocks(start = this.getPositionVector(), end = new Vec3d(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ), false, true, false)) != null) {
            float remainX = (float)(result.hitVec.x - this.posX);
            float remainY = (float)(result.hitVec.y - this.posY);
            float remainZ = (float)(result.hitVec.z - this.posZ);
            double remDist = Math.sqrt(remainX * remainX + remainY * remainY + remainZ * remainZ);
            this.stickPos = result.getBlockPos();
            this.posX -= (double)remainX / remDist * 0.05;
            this.posY -= (double)remainY / remDist * 0.05;
            this.posZ -= (double)remainZ / remDist * 0.05;
            this.posX += (double)remainX;
            this.posY += (double)remainY;
            this.posZ += (double)remainZ;
            this.motionX *= (double)(0.75f - this.rand.nextFloat());
            this.motionY *= -0.30000001192092896;
            this.motionZ *= (double)(0.75f - this.rand.nextFloat());
            this.inGround = true;
        } else {
            this.posX += this.motionX;
            this.posY += this.motionY;
            this.posZ += this.motionZ;
            this.inGround = false;
        }
        double hMotion = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        this.rotationYaw = (float)Math.toDegrees(Math.atan2(this.motionX, this.motionZ));
        this.rotationPitch = (float)Math.toDegrees(Math.atan2(this.motionY, hMotion));
        while (this.rotationPitch - this.prevRotationPitch < -180.0f) {
            this.prevRotationPitch -= 360.0f;
        }
        while (this.rotationPitch - this.prevRotationPitch >= 180.0f) {
            this.prevRotationPitch += 360.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw < -180.0f) {
            this.prevRotationYaw -= 360.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw >= 180.0f) {
            this.prevRotationYaw += 360.0f;
        }
        this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2f;
        this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2f;
        float f3 = 0.98f;
        float f5 = 0.04f;
        if (this.isInWater()) {
            this.fuse += 2000;
            for (int i1 = 0; i1 < 4; ++i1) {
                float f6 = 0.25f;
                world.spawnParticle(EnumParticleTypes.WATER_BUBBLE, this.posX - this.motionX * (double)f6, this.posY - this.motionY * (double)f6, this.posZ - this.motionZ * (double)f6, this.motionX, this.motionY, this.motionZ, new int[0]);
            }
            f3 = 0.75f;
        }
        this.motionX *= (double)f3;
        this.motionY *= (double)f3;
        this.motionZ *= (double)f3;
        this.motionY -= (double)f5;
        this.setPosition(this.posX, this.posY, this.posZ);
    }

    public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
        nbttagcompound.setByte("inGround", (byte)(this.inGround ? 1 : 0));
    }

    public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
        this.inGround = nbttagcompound.getByte("inGround") == 1;
    }

    public void explode() {
        PointExplosion explosion = new PointExplosion(this.getEntityWorld(), this, this.owner, this.posX, this.posY, this.posZ, 1.0f, 1.0f, 20);
        explosion.doExplosionA();
        explosion.doExplosionB(true);
    }
}

