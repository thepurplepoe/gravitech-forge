/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.upgrade;

public enum UpgradableProperty {
    Processing,
    Augmentable,
    RedstoneSensitive,
    Transformer,
    EnergyStorage,
    ItemConsuming,
    ItemProducing,
    FluidConsuming,
    FluidProducing;
    

    private UpgradableProperty() {
    }
}

