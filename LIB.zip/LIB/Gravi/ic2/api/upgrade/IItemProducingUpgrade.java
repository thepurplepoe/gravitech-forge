/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.upgrade;

import ic2.api.upgrade.IUpgradeItem;

public interface IItemProducingUpgrade
extends IUpgradeItem {
}

