/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package ic2.api.upgrade;

import ic2.api.upgrade.IUpgradableBlock;
import ic2.api.upgrade.IUpgradeItem;
import net.minecraft.item.ItemStack;

public interface IAugmentationUpgrade
extends IUpgradeItem {
    public int getAugmentation(ItemStack var1, IUpgradableBlock var2);
}

