/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.network;

public interface INetworkUpdateListener {
    public void onNetworkUpdate(String var1);
}

