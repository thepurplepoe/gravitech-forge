/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.network;

import java.util.List;

public interface INetworkDataProvider {
    public List<String> getNetworkedFields();
}

