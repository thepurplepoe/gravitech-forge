/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 */
package ic2.api.network;

import net.minecraft.entity.player.EntityPlayer;

public interface INetworkClientTileEntityEventListener {
    public void onNetworkEvent(EntityPlayer var1, int var2);
}

