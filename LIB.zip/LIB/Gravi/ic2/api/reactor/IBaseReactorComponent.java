/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package ic2.api.reactor;

import ic2.api.reactor.IReactor;
import net.minecraft.item.ItemStack;

public interface IBaseReactorComponent {
    public boolean canBePlacedIn(ItemStack var1, IReactor var2);
}

