/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.reactor;

import ic2.api.reactor.IReactor;

public interface IReactorChamber {
    public IReactor getReactorInstance();

    public boolean isWall();
}

