/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.util;

import ic2.api.util.IKeyboard;

public class Keys {
    public static IKeyboard instance;
}

