/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.info;

public interface ITeBlock {
}

