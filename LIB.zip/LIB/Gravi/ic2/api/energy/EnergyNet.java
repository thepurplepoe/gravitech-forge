/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.energy;

import ic2.api.energy.IEnergyNet;

public final class EnergyNet {
    public static IEnergyNet instance;
}

