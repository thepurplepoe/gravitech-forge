/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.tileentity.TileEntity
 */
package ic2.api.energy.prefab;

import ic2.api.energy.prefab.BasicEnergyTile;
import ic2.api.energy.prefab.BasicSink;
import ic2.api.energy.prefab.BasicSource;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;

public class BasicEnergyTe<T extends BasicEnergyTile>
extends TileEntity {
    protected T energyBuffer;

    protected BasicEnergyTe() {
    }

    public T getEnergyBuffer() {
        return this.energyBuffer;
    }

    public void onLoad() {
        this.energyBuffer.onLoad();
    }

    public void invalidate() {
        super.invalidate();
        this.energyBuffer.invalidate();
    }

    public void onChunkUnload() {
        this.energyBuffer.onChunkUnload();
    }

    public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        this.energyBuffer.readFromNBT(nbt);
    }

    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        return this.energyBuffer.writeToNBT(super.writeToNBT(nbt));
    }

    public static class Source
    extends BasicEnergyTe<BasicSource> {
        public Source(int capacity, int tier) {
            this.energyBuffer = new BasicSource(this, (double)capacity, tier);
        }
    }

    public static class Sink
    extends BasicEnergyTe<BasicSink> {
        public Sink(int capacity, int tier) {
            this.energyBuffer = new BasicSink(this, (double)capacity, tier);
        }
    }

}

