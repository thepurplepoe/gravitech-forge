/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.energy.tile;

public interface IChargingSlot {
    public double charge(double var1);
}

