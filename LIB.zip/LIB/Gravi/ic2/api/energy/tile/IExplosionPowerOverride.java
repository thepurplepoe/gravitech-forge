/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.energy.tile;

public interface IExplosionPowerOverride {
    public boolean shouldExplode();

    public float getExplosionPower(int var1, float var2);
}

