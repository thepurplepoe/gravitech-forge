/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.energy.tile;

public interface IDischargingSlot {
    public double discharge(double var1, boolean var3);
}

