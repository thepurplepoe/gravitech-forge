/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package ic2.api.recipe;

import net.minecraft.item.ItemStack;

public interface ICraftingRecipeManager {
    public /* varargs */ void addRecipe(ItemStack var1, Object ... var2);

    public /* varargs */ void addShapelessRecipe(ItemStack var1, Object ... var2);

    public static class AttributeContainer {
        public final boolean hidden;
        public final boolean consuming;

        public AttributeContainer(boolean hidden, boolean consuming) {
            this.hidden = hidden;
            this.consuming = consuming;
        }
    }

}

