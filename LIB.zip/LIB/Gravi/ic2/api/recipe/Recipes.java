/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package ic2.api.recipe;

import ic2.api.recipe.IBasicMachineRecipeManager;
import ic2.api.recipe.ICannerBottleRecipeManager;
import ic2.api.recipe.ICannerEnrichRecipeManager;
import ic2.api.recipe.ICraftingRecipeManager;
import ic2.api.recipe.IElectrolyzerRecipeManager;
import ic2.api.recipe.IEmptyFluidContainerRecipeManager;
import ic2.api.recipe.IFermenterRecipeManager;
import ic2.api.recipe.IFillFluidContainerRecipeManager;
import ic2.api.recipe.IFluidHeatManager;
import ic2.api.recipe.ILiquidHeatExchangerManager;
import ic2.api.recipe.IListRecipeManager;
import ic2.api.recipe.IMachineRecipeManager;
import ic2.api.recipe.IRecipeInput;
import ic2.api.recipe.IRecipeInputFactory;
import ic2.api.recipe.IScrapboxManager;
import ic2.api.recipe.ISemiFluidFuelManager;
import net.minecraft.item.ItemStack;

public class Recipes {
    public static IRecipeInputFactory inputFactory;
    public static IMachineRecipeManager<ItemStack, ItemStack, ItemStack> furnace;
    public static IBasicMachineRecipeManager macerator;
    public static IBasicMachineRecipeManager extractor;
    public static IBasicMachineRecipeManager compressor;
    public static IBasicMachineRecipeManager centrifuge;
    public static IBasicMachineRecipeManager blockcutter;
    public static IBasicMachineRecipeManager blastfurnace;
    public static IBasicMachineRecipeManager recycler;
    public static IBasicMachineRecipeManager metalformerExtruding;
    public static IBasicMachineRecipeManager metalformerCutting;
    public static IBasicMachineRecipeManager metalformerRolling;
    public static IBasicMachineRecipeManager oreWashing;
    public static ICannerBottleRecipeManager cannerBottle;
    public static ICannerEnrichRecipeManager cannerEnrich;
    public static IElectrolyzerRecipeManager electrolyzer;
    public static IFermenterRecipeManager fermenter;
    public static IMachineRecipeManager<IRecipeInput, Integer, ItemStack> matterAmplifier;
    public static IScrapboxManager scrapboxDrops;
    public static IListRecipeManager recyclerBlacklist;
    public static IListRecipeManager recyclerWhitelist;
    public static ICraftingRecipeManager advRecipes;
    public static ISemiFluidFuelManager semiFluidGenerator;
    public static IFluidHeatManager fluidHeatGenerator;
    public static ILiquidHeatExchangerManager liquidCooldownManager;
    public static ILiquidHeatExchangerManager liquidHeatupManager;
    public static IEmptyFluidContainerRecipeManager emptyFluidContainer;
    public static IFillFluidContainerRecipeManager fillFluidContainer;
}

