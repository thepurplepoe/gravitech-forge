/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nonnull
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockMycelium
 *  net.minecraft.block.BlockSand
 *  net.minecraft.init.Blocks
 */
package ic2.api.crops;

import javax.annotation.Nonnull;
import net.minecraft.block.Block;
import net.minecraft.block.BlockMycelium;
import net.minecraft.block.BlockSand;
import net.minecraft.init.Blocks;

public enum CropSoilType {
    FARMLAND(Blocks.FARMLAND),
    MYCELIUM((Block)Blocks.MYCELIUM),
    SAND((Block)Blocks.SAND),
    SOULSAND(Blocks.SOUL_SAND);
    
    private final Block block;

    private CropSoilType(Block block) {
        this.block = block;
    }

    public Block getBlock() {
        return this.block;
    }

    public static boolean contais(Block block) {
        for (CropSoilType aux : CropSoilType.values()) {
            if (aux.getBlock() != block) continue;
            return true;
        }
        return false;
    }
}

