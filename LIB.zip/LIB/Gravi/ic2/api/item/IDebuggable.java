/*
 * Decompiled with CFR 0_124.
 */
package ic2.api.item;

public interface IDebuggable {
    public boolean isDebuggable();

    public String getDebugText();
}

