/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package ic2.api.item;

import net.minecraft.item.ItemStack;

public interface IBoxable {
    public boolean canBeStoredInToolbox(ItemStack var1);
}

