/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package ic2.api.item;

import ic2.api.item.IElectricItemManager;
import net.minecraft.item.ItemStack;

public interface IBackupElectricItemManager
extends IElectricItemManager {
    public boolean handles(ItemStack var1);
}

