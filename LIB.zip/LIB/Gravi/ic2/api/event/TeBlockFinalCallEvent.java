/*
 * Decompiled with CFR 0_124.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.Event
 */
package ic2.api.event;

import net.minecraftforge.fml.common.eventhandler.Event;

public final class TeBlockFinalCallEvent
extends Event {
}

